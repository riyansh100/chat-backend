module ws-pull-tester

go 1.22

require github.com/gorilla/websocket v1.5.3
